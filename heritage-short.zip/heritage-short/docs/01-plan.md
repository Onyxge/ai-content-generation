# 01 — Plan

Architecture, build order and risks for The Heritage Short. Decisions marked ADR-nnn are in `decisions.md`; requirements are in `00-requirements.md`.

Revised 2026-11-25 (build-log Entry 1): the build starts on Wednesday 25 November, not Tuesday, so the schedule and priorities were re-cut; compute is Kaggle plus Colab; the film is bilingual. Updated after Entry 2: decisions locked and the story-agnostic core built.

## 1. Goal

A small studio in code. One file, `storyboard.json`, describes the film. A script stage drafts it, six rendering stages turn it into a film, and an agent layer helps us write and judge it. English narration must exist and Amharic is wanted, so language is a dimension of the pipeline: pictures and music are shared, and only narration and assembly run per language (ADR-015). Every model call is cached, logged and costed, and anyone can rebuild the film with one command. The deadline is Thu 26 Nov, 23:59 EAT, about a day and a half after the build starts, so we aim to submit by 21:00 and cut scope before we cut quality.

## 2. Principle: agents plan and judge, the pipeline executes

Two different agents are involved. Claude Code is the coding agent that writes the pipeline. The movie agent is part of the pipeline: a Gemini-powered director that drafts the storyboard and, if time allows, a critic that checks the pictures. This section is about the movie agent.

An agent that makes the movie by calling models in a loop would be fun to watch and bad to grade. The rubric pays for determinism: a validated contract, a cache that regenerates only what changed, a rebuild from a clean clone, and a live demo where one edit produces one new model call. A free-running agent makes every run different and spends scarce quota on retries nobody sees.

So the agents never call a generation model. The director turns our story notes into a storyboard draft; the critic looks at keyframes and writes a verdict. Both produce data: an edit to `storyboard.json` (validated, shown as a diff, approved by Y) or a line in the logs. The pipeline then renders whatever the contract says. Because every agent decision ends up in the contract as a prompt, a seed or a selected option, the film rebuilds identically without the agent.

ADR-002 compares three levels of autonomy with a worked example. A fully autonomous loop is this design with approval pressed automatically, so the design can grow into it one decision at a time; the critic could, for instance, retry a bad keyframe up to three times on its own while the storyboard stays under Y's approval. Y chose the lean version on 2026-11-25: the director now, the critic only if the rough cut is done early.

## 3. Architecture

```
 docs/story/brief.md   (public version; private notes stay in private/)
        │
        │  director agent: Gemini 3.8 Flash, output constrained by the schema
        ▼
 storyboard.json ──► validate (schema + lint + consent gate) ──► film plan (misses, quota, GPU minutes)
        │                         ▲
        │        Y approves diffs; user tests change it
        │
        ├─► references ──► keyframes ──► (critic) ──► shots: Wan 2.2 via the GPU runner, or Ken Burns locally
        ├─► narration (one WAV per shot per language) ──► timeline per language
        ├─► music (cue → three candidates → pinned pick)
        ▼
     assemble (FFmpeg), per language and orientation:
     fit picture to voice, duck, subtitles, loudnorm, end card
        ▼
     film_en_9x16.mp4 · film_en_16x9.mp4 · film_am_9x16.mp4 · film_am_16x9.mp4 · .srt files

 every model call → runs.jsonl · every stage → stages.jsonl · every artifact → sidecar .json
```

| Layer | Job | Where it lives |
|---|---|---|
| Contract | Schema, the storyboard itself, cross-field lint | `schema/storyboard.schema.json`, `storyboard.json`, `pipeline/contract.py` |
| Engine | Dependency order, cache, logs, retries, quota ledger, dry-run plan | `pipeline/engine/` |
| Stages | One script per stage, each runnable alone | `pipeline/{script,references,keyframes,shots,narration,music,assemble}.py` |
| Providers | Thin adapters behind one interface, picked by config, so swapping a model is a config change | `pipeline/providers/` (gemini_text, gemini_tts, cf_flux, gpu_jobs, ffmpeg, mock) |
| GPU runner | One script that runs a job bundle on Kaggle or Colab and writes each result as it finishes | `gpu/runner.py`, launcher notebooks in `gpu/` |
| Agents | Director (story → storyboard draft); critic (keyframe QA, if time) | `agents/` |
| Interfaces | `film` CLI and Makefile; an MCP server after the deadline | `pipeline/cli.py`, `Makefile` |

## 4. Stages

| Stage | Unit | Reads from the storyboard | Needs | Writes | Primary → fallback | Runs on |
|---|---|---|---|---|---|---|
| script¹ | film | nothing yet: the brief and DESIGN.md intent | — | `storyboard.json` draft | Gemini 3.8 Flash → current Flash-Lite | Gemini API |
| references | option | style block, character descriptions | — | `outputs/references/` | FLUX.2 klein 4B → FLUX.1 schnell | Cloudflare |
| keyframes | shot | image prompt, characters, seed | references | `outputs/keyframes/` | klein 4B with up to four references → schnell, text only | Cloudflare |
| shots | shot | motion prompt, mode, seed | keyframe | `outputs/shots/` | Wan 2.2 TI2V-5B → Ken Burns | Kaggle T4 (or Colab) through the runner; Ken Burns locally |
| narration | shot × language | spoken line and voice for that language | — | `outputs/narration/<lang>/` | 3.8 Flash TTS → 3.8 Flash-Lite TTS | Gemini API |
| music | cue × seed | caption, bpm, key, length | — | `outputs/music/` | ACE-Step 1.5 → synthetic drone (temp track only) | Colab (or Kaggle) through the runner |
| assemble | language × orientation | everything | all of the above | `outputs/final/` | FFmpeg | local |

¹ An authoring step run with `make storyboard`, not part of `make film` (ADR-003).

Remote GPU work goes through one runner script (ADR-006). `film bundle shots` packs the uncached jobs into a bundle (a manifest plus keyframes). We run it by hand on Kaggle as a saved version with both T4s, so it keeps going after the browser closes, or on Colab. `film ingest` brings the results into the cache with timings measured on the GPU. Until a clip comes back, assembly uses the Ken Burns fallback, so `make film` always produces a complete film. Pushing bundles to Kaggle from the CLI is a stretch goal (U11).

## 5. The contract

The schema is hand-written and is also handed to Gemini as the structured-output constraint when the director drafts, so the agent can't produce an invalid contract (ADR-001). A first sketch, finalised in unit U1:

```json
{
  "version": 1,
  "meta": { "title": "…", "languages": ["en", "am"], "primary": "en", "runtime_s": [60, 90] },
  "style": { "block": "warm hand-painted gouache, soft golden-hour light, light film grain",
             "avoid": "text, letters, logos, extra fingers" },
  "characters": [{ "id": "grandmother", "real_person": true, "consent_id": "C1",
                   "description": "…", "reference": "ref_grandmother" }],
  "references": [{ "id": "ref_grandmother", "prompt": "…", "seeds": [41, 42, 43, 44], "selected": 42 }],
  "voices": {
    "en": { "model": "gemini-3.8-flash-tts", "voice": "…", "style": "warm, unhurried, intimate" },
    "am": { "model": "gemini-3.8-flash-tts", "voice": "…", "style": "warm, unhurried, intimate" }
  },
  "shots": [{
    "id": "s01",
    "reason": "Show the village at dawn so the walk to the market has a place to start.",
    "beat": "opening", "size": "extreme wide", "duration_s": 6, "characters": [],
    "image_prompt": "…", "keyframe_seed": 1001,
    "motion": { "mode": "i2v", "fallback": "kenburns", "prompt": "slow push-in, mist drifting", "seed": 2001 },
    "narration": { "en": "…spoken words only…", "am": "…" }
  }],
  "music": { "cues": [{ "id": "m1", "from": "s01", "to": "s12", "caption": "…", "instrumental": true,
                        "bpm": 70, "key": "D minor", "length_s": 100,
                        "seeds": [11, 12, 13], "selected": 12, "why": "…" }] },
  "end_card": { "lines": ["Made with AI", "…"], "duration_s": 3 }
}
```

Narration holds only the spoken words, because Gemini 3.8 TTS reads its input verbatim; voice and style live in `voices`. The English script is the single source of meaning: it is the English narration and also the English subtitle track of the Amharic film, and a shot can override it with `subtitle_en` when a faithful subtitle should differ from what is spoken. `meta.primary` names the version we submit as main; it starts as English and may change after the user tests (ADR-015). Music cues point at shot ids, not seconds, so they survive timing changes in either language. The lint step covers what JSON Schema can't: 8–12 shots; a runtime of 60–90 s for every language; unique ids and references that resolve; the consent gate (ADR-014); narration length against shot length (about 2–2.5 words per second for English until measured; Amharic measured from the radio cut); subtitle chunks of at most two lines of about 40 characters; and a warning when a prompt asks for text inside the image.

## 6. Caching, and how "only that shot regenerates" works

Each unit's cache key is the sha256 of canonical JSON (sorted keys, relative POSIX paths) of: stage, stage version, provider, model, parameters, seed, the fully resolved prompt, and the file hashes of the upstream artifacts it uses. The artifact is written next to a sidecar JSON holding the key, run id, model, parameters and the artifact's own hash. A unit is skipped when the sidecar's key matches and the file's hash checks out (ADR-004). Narration units are keyed per language, so an English edit never touches the Amharic audio, and the other way round.

Two rules make the walkthrough work. Changes cascade only along real dependencies, because a downstream key includes upstream file hashes. And no key depends on whole-film values: music length and clip frame counts come from the storyboard, never from measured narration or total runtime, so fitting everything together happens in assembly, which is cheap and always reruns.

Example: change the image prompt of shot 4. Its keyframe key changes, so one image is generated. Shot 4's clip key includes that image's hash, so one clip is regenerated (by Wan through the runner, or by a free Ken Burns render). Narration, music and the other eleven shots hit the cache, and assembly reruns. `film plan` predicts exactly that before anything is spent, and runs.jsonl gains one or two lines. Change an English narration line instead and you get one TTS call plus the English assemblies.

Current artifacts are committed, so a fresh clone with no keys and no GPU rebuilds the film from the cache; CI proves it on every push. Explored but unpicked variants go to a gitignored archive.

## 7. Logs and measurement

Every model-call attempt appends one line to `runs.jsonl` (ADR-007). An illustrative line, pretty-printed here, with made-up numbers:

```json
{"ts": "2026-11-25T21:14:03+03:00", "run_id": "r-20261125-2112", "stage": "keyframes",
 "unit": "s04", "attempt": 1, "provider": "cloudflare",
 "model": "@cf/black-forest-labs/flux-2-klein-4b",
 "params": {"width": 704, "height": 1280, "refs": ["ref_grandmother#42"]}, "seed": 1004,
 "prompt_sha": "9f2c…", "cache_key": "3b7e…", "status": "ok",
 "latency_ms": 2140, "gpu_s": null, "cost_usd_list": 0.0, "cost_basis": "see config/pricing.yaml",
 "quota": {"day": "2026-11-25", "used_today": 38},
 "output": "outputs/keyframes/s04.png", "output_sha": "c81d…", "error": null}
```

`stages.jsonl` gets one line per stage per run: cache hits and misses, wall time, and the measurements that prove what graders can't see or hear (narration durations per language, loudness and true peak per stem and for the final mix, how far the music dips under the voice, export runtimes and sizes). `film costs` turns both logs into COSTS.md tables: calls, median and p95 latency, and GPU minutes per stage, free-tier use against the caps we actually hit, and a list-price equivalent from a pricing file that records each price's source and date.

## 8. When things fail

| Failure | Example | What the pipeline does |
|---|---|---|
| Transient | Per-minute 429, 5xx, timeout | Exponential backoff with jitter, honours Retry-After, up to four attempts, every attempt logged |
| Daily quota | TTS or image allowance used up | Stops calling that provider, marks the remaining units deferred, uses the configured fallback if allowed, exits in a resumable state, logs the cap from the error body |
| Bad input | Invalid storyboard, 400 | Fails before any model call, naming the field |
| Safety block | Prompt refused | Marks the unit "needs prompt edit" and carries on with the others |
| Remote job | Out of memory, timeout, Kaggle or Colab session killed | The runner saves each output as it finishes; we ingest what came back and rebundle only what's missing |
| Quality | Critic or Y rejects a keyframe or clip | New seed, at most three attempts per shot, then the fallback and a FAILURES.md entry |

Before any run that spends quota, `film plan` lists misses per stage, projected calls, GPU minutes and what's left of each daily allowance (ADR-008).

## 9. The agent layer

The director is part of the script stage (U4). It reads the public story brief and the audience and intent section of DESIGN.md, and writes a storyboard draft constrained by the schema: a reason for every shot, English narration, and an Amharic translation. The draft is linted and shown as a diff against the current storyboard, and nothing is committed without Y's approval. A native speaker checks the Amharic text before any Amharic speech is generated; we don't take a translation on trust. Private notes never reach it (ADR-013).

The critic (U10, a Could under the deadline) reads a keyframe, the golden reference and the shot spec, and returns a JSON verdict (identity match, style match, problems with hands, faces or stray text, pass or fail), logged like any model call. In explore mode it ranks seed candidates and proposes pins for Y to confirm. If it's built, we measure how often it agrees with Y's own picks, because that tells us whether this judgment can be delegated (E13).

Seeds follow explore, pick, pin (ADR-009): `--explore N` renders N candidates into the archive, the chosen seed is written back into the storyboard, and normal runs use pinned seeds only.

After the deadline, an MCP server over the same CLI (validate, plan, render a stage, regenerate a shot, pin, costs) would let any coding agent drive the studio (U12).

## 10. Two aspect ratios from one generation (open)

The vertical file is the main submission, so it has to look best, and we can't afford two Wan runs per shot. Wan's image-to-video output follows the input image's aspect ratio, which leaves three options. A square master can be centre-cropped both ways, so one clip serves both, at the cost of strictly centred composition and an upscale of about 1.33× at 720p (2× at 480p). A vertical master gives native quality where it matters, with the horizontal version built as a blurred-fill pillarbox, which reads as a social repost. Separate generations per orientation double the GPU bill, so that one is out. The default is the vertical master; we test the square one with two clips during spike S1 and decide when S1 returns (ADR-011, E9). Ken Burns shots don't have this problem: they're rendered natively in both orientations from a keyframe generated with room to crop.

## 11. Testing and CI

Unit tests cover schema fixtures, cache-key stability across operating systems, lint rules, subtitle chunking, timeline maths and the FFmpeg filter-graph builder. Mock providers produce labelled placeholder images, tones and clips, so `make film MOCK=1` runs the whole pipeline offline in seconds. CI runs on every push: tests, the mock film, gitleaks, and a reproduce job that clones fresh, runs `make film` with no keys, and asserts zero new lines in runs.jsonl and exports of 60–90 s. Those CI logs are text the graders can read.

## 12. User tests

Two rounds, each with at least three people from the intended audience: the radio cut on Wednesday evening and the near-final cut early on Thursday afternoon. Recruit both rounds now; sending the cut to someone's phone works. Prefer bilingual testers: they can hear both versions, and they count for whichever becomes the main. Play it once with no introduction, then ask three questions: in one sentence, what was it about; which moment stayed with you; where were you lost or bored. Round two adds: would you forward it, and to whom; could you read the subtitles on your phone; and, for bilingual testers, which version they would send to family.

Before each round the storyboard is snapshotted to `docs/storyboard-history/vN.json`. Afterwards DESIGN.md gets one row per tester:

| Tester (initials, relation to audience) | Version heard | Channel | What they said, in their words | Insight | Change (storyboard version, shot) |
|---|---|---|---|---|---|

## 13. Schedule

| When (EAT) | Y | Claude Code | Checkpoint |
|---|---|---|---|
| Wed, now to early evening | Keys and accounts (Gemini, Cloudflare, Kaggle, Colab); pick the story and talk to the person; record consent; recruit testers for both rounds; write audience and intent in DESIGN.md before any model call | U0–U3; launch spike S1 on Kaggle by hand | DESIGN.md committed; smoke test logged; S1 running |
| Wed evening | Approve storyboard v1; check the Amharic text | U4: director, English narration, radio cut; Amharic if quota allows | Radio cut sent to testers by 22:00 at the latest |
| Wed late evening | Pick the golden reference; glance at the keyframes | U5; U6 Ken Burns; launch the Wan batch on Kaggle and the ACE-Step candidates on Colab before bed | Rough cut with a picture for every shot |
| Thu morning | Read test 1 and approve storyboard v2; pick the music | Ingest Wan clips and music; re-voice changed lines (after the 11:00 reset if the quota is spent); U8 | Test 1 in DESIGN.md with the v1 → v2 diff; near-final cut by about 13:00 |
| Thu early afternoon | Test 2 with at least three people | U9: costs tables, CI, clean-clone check; drafts of README, ARCHITECTURE and ETHICS | Feedback in by about 16:00 |
| Thu late afternoon and evening | Apply test 2; record the walkthrough; public post with the AI label on; write the report | Final exports in both languages and orientations | Test 2 in DESIGN.md with the v2 → v3 diff |
| Thu 21:00 | Submit both assignments | — | About three hours of buffer before 23:59 |

Anything marked Could in §14 starts only after the rough-cut checkpoint, and only if Thursday's checkpoints are on time.

## 14. Units of work for Claude Code

| Unit | Priority | Scope | Done when |
|---|---|---|---|
| U0 Repo and hygiene | Must | uv project, `film` CLI skeleton, Makefile, `.env.example`, `.gitignore` (private/, .env, archive), gitleaks pre-commit, skeletons of the required root docs | `make check` passes on a fresh clone; secret scan clean |
| U1 Contract | Must | Schema v1 with languages; lint for runtime per language, ids, consent gate, words per second, subtitle length; good and bad fixtures; `film validate` | Bad fixtures fail with the field path; Gemini accepts the schema, or a generated reduced copy |
| U2 Engine | Must | Canonical cache keys, sidecars, dependency order, runs and stages writers, retry and backoff, quota ledger, `film plan`, mock providers | Mock film runs end to end offline; editing one mock prompt makes `film plan` report exactly that unit and its dependants |
| U3 Providers, smoke test, GPU runner | Must | Gemini text, Gemini TTS, Cloudflare FLUX, FFmpeg wrapper; `make smoke`; `gpu/runner.py` with `film bundle` and `film ingest` | One runs.jsonl line per provider with latency; S1 running on Kaggle |
| U4 Script stage, narration, radio cut | Must | Director v1 (brief → draft → lint → diff); per-shot TTS per language, English first; timeline per language; radio cut over a synthetic temp drone | Storyboard v1 validates; English radio cut plays end to end; Amharic if quota allows |
| U5 References and keyframes | Must | Reference options, golden pick pinned, keyframes conditioned on it, explore mode | Every shot has a keyframe; faces and hands checked |
| U6 Shots | Must | Ken Burns renderer in both orientations; Wan through the runner with ingest | Rough cut with a picture per shot; Wan clips ingested through the cache |
| U7 Music | Must | Cue spec → three ACE-Step candidates on Colab → pinned pick with a reason | Candidates logged; pick written into the storyboard |
| U8 Assembly | Must | Fit to voice, ducking, subtitles styled per orientation, two-pass loudnorm, end card, exports per language and orientation, measurements | All exports 60–90 s; loudness within 1 LU of target; ducking depth logged |
| U9 Reporting and CI | Must | `film costs` → COSTS.md tables; storyboard snapshots and diffs for DESIGN.md; CI with tests, mock film and clean-clone rebuild | Tables regenerate from the logs; CI green on a fresh clone |
| U10 Critic agent | Could | Keyframe verdicts, seed ranking in explore mode, agreement with Y's picks | Verdicts logged; agreement computed |
| U11 Kaggle push from the CLI | Could | `film push shots` drives `kaggle kernels push` with the T4 named, polls, downloads, ingests | One bundle round-trips without opening a browser |
| U12 MCP server | Next | The studio's commands as MCP tools | After the deadline |

Progress (build-log Entry 2, Wed 25 Nov): U0, U1 and U2 are done, and most of U8 was built early: assembly, subtitles, ducking, loudness, the end card and the radio cut. All of it is tested on mock providers. Still open: the CI job (moved to U9), Gemini's acceptance of the schema (checked in U4), the daily quota ledger (with U3's real providers), `--explore` (U5), and in U8 the two-pass loudnorm and a measured ducking depth.

## 15. Spikes to run first

| Spike | Question | How | Decision it feeds |
|---|---|---|---|
| S1 Wan on a Kaggle T4 | Can we get motion at all, how fast, at what resolution? | Run the runner as a saved Kaggle version with GPU T4 x2 on one smoke keyframe; try TI2V-5B with offloading at 480p, then the distilled FastWan build, then a GGUF build; record seconds per clip, peak VRAM and weight download time; add one square input for E9 | At 12 minutes or less per 5 s clip, Wan for 6–8 shots; otherwise 2–3 and Ken Burns elsewhere (ADR-005, 006, 011) |
| S2 ACE-Step on Colab | How long does a 30 s instrumental take? | Colab T4, each output saved to Drive as it finishes | Whether three candidates fit into this evening |
| S3 TTS in both languages | How do both TTS models handle English and Amharic, including names, and what is our real daily cap? | Two lines per language through each model; one native listen | Voice, model split and quota plan (E1, E3, E16) |
| S4 Reference conditioning | Does klein keep the character with one reference image? | Two shots, references on and off, same seeds | Reference-sheet design (E4) |

## 16. Experiment backlog

The brief asks for at least ten. Each changes one thing, keeps the seed fixed, and cites its run ids. Under the deadline we favour the cheap ones: E11, E12, E14 and E15 cost no quota, and E7 and E9 come out of spike S1.

| ID | Hypothesis | The one change | Measure | Cost |
|---|---|---|---|---|
| E1 | Style words typed into the narration get spoken by 3.8 TTS; the style field doesn't | Inline style prefix vs style field, same line and voice | Native listen | 2 TTS calls |
| E2 | A style instruction improves narration more than switching voices | Three voices with one style vs one voice with and without style | Native preference | 4 TTS calls |
| E3 | Flash-Lite TTS is good enough for the English version | Same line through Flash and Flash-Lite | Rating, latency | 2 TTS calls |
| E4 | Conditioning on the golden reference keeps the character recognisable | References on vs off, same prompts and seeds, four shots | Y's blind pick (and the critic's score, if built) | 8 images |
| E5 | klein 9B looks better than 4B by enough to accept its non-commercial licence | 4B vs 9B, same seeds | Blind preference, latency | 6 images |
| E6 | A fixed style block drifts less than describing the style per shot | Shared block vs per-shot wording | Side-by-side judgment | 8 images |
| E7 | 480p drafts save most of the GPU time for an acceptable loss | 480p vs 720p, same keyframe and seed | Seconds per clip, peak VRAM, side by side | 2 clips |
| E8 | Motion-only prompts beat re-describing the subject in image-to-video | Motion and camera only vs full description | Morphing and identity notes | 2 clips |
| E9 | A square master can serve both orientations | Square vs vertical master | Crop quality in both exports | 2 clips |
| E10 | The quietest of three score candidates works best under the voice | Three ACE-Step candidates | Listening under narration at low volume, reasons written | 3 tracks |
| E11 | The brief's ducking defaults suit our voice | Threshold and ratio variants | Measured music dip under the voice, in dB | FFmpeg only |
| E12 | Normalising each stem first makes mixing a creative choice rather than a repair | With vs without per-stem loudness normalisation | Loudness spread, listening notes | FFmpeg only |
| E13 | The critic agrees with Y's picks often enough to delegate continuity checks | Critic ranking vs Y's blind picks | Agreement rate and where it disagrees | About 20 vision calls, only if U10 is built |
| E14 | Viewers prefer real motion for people but not for places | Wan vs Ken Burns per shot in test 2 | Tester picks | No compute |
| E15 | The same meaning runs longer in Amharic than in English | Same script in both languages, same voice settings | Measured seconds per shot and in total, words per second | No extra calls |
| E16 | Respelling a name phonetically fixes an Amharic mispronunciation | Original vs respelled name in one line | Native listen | 2 TTS calls |

## 17. Ceiling

The brief judges ceiling work on insight, not volume, and our clock is short, so the ceiling should be work we're doing anyway, measured properly. Making the film in English and Amharic from one storyboard is the brief's "more languages" direction. We measure where Amharic speech fails against English (names, numbers, prosody), how much longer the same meaning runs in each language (E15), whether respelling fixes names (E16), and which version lands with which part of the audience (both user tests). The agent-ready studio, an MCP server plus a measured critic, moves to the report's "what we'd build next".

## 18. Risks

| Risk | Likelihood | Impact | Mitigation | Early warning |
|---|---|---|---|---|
| The compressed timeline: about a day and a half | High | High | Musts before Coulds; manual GPU launch; critic, CLI push and MCP cut to Could or Next; submit by 21:00 | Radio cut not sent by Wed 22:00 |
| Wan won't fit or is too slow on a T4 | High | Medium | Spike S1 first; 480p; distilled or quantised build; HunyuanVideo 1.5 as the alternative; Ken Burns floor | Out of memory, or more than 15 min per clip |
| The TTS daily cap blocks narration | Medium | High | Per-line cache; `film plan` before spending; quotas are per model, so English can move to Flash-Lite; if the cap is tiny, voice the radio cut in one request per language and go per line once lines are stable; post-test fixes land after Thursday's 11:00 reset | A 429 with a daily quota in its body |
| Missing consent zeroes the film | Low | Critical | Consent before generation; the lint refuses to run without it | A character with `real_person: true` and no `consent_id` |
| Amharic speech or translation isn't good enough | Medium | Medium | Native check of the text before TTS and of the audio after; respell names; English is the guaranteed version | A native listener rejects a line |
| Character drifts between shots | Medium | Medium | Reference sheet, style block in every prompt, klein reference images, one main character; critic if built | Faces differ at a glance across keyframes |
| Testers late or unavailable | Medium | High | Recruit both rounds now; async on phones; bilingual testers; Slack colleagues as extra voices | No replies to the radio cut by Thu 09:00 |
| Scope creep from agent and ceiling ideas | High | High | Ceiling is the bilingual comparison we're building anyway; Coulds wait for the rough cut | Rough cut not done by Thu 09:00 |
| GPU friction: wrong GPU, session limits, about 18 GB of weights per Kaggle session, Colab without a GPU | Medium | Medium | GPU T4 x2 chosen explicitly; download time measured in S1; Kaggle primary, Colab second lane; outputs saved as they finish | S1 timings; Colab refuses a GPU |
| Private family details leak into the public repo or a training set | Low | High | private/ gitignored; prompts use roles and first names; history scanned before the repo goes public | gitleaks or a manual review flags it |
| Model names or endpoints change mid-build | Medium | Low | Adapters and config; smoke test; FAILURES.md entry | Smoke test fails |
| Daily image allowance runs out | Medium | Medium | References and keyframes this evening, before the overnight Wan batch; exploration capped; schnell fallback | Ledger shows under 20% left |

## 19. Open decisions

| Decision | Options | Recommendation | Status |
|---|---|---|---|
| Story, subject and consent | Y's call | One person, one place, three to five beats, consent recorded first | Needed now |
| Narration languages | English only; both, English first; Amharic main with English second | Both from one storyboard, English first, the tests pick the main (ADR-015) | Decided 2026-11-25 |
| Agent autonomy | Plan and judge; fully autonomous; pipeline first | Plan and judge, lean: director now, critic if time (ADR-002) | Decided 2026-11-25 |
| Compute | — | Kaggle T4 x2 for video, Colab for music and overflow; no local GPU, no frontier key (ADR-006) | Decided 2026-11-25 |
| Aspect strategy | Square master; vertical master with blurred fill | Vertical by default, square tested in S1 (ADR-011) | When S1 returns |
| Ceiling direction | Bilingual comparison; agent-ready studio; consistency measurement; a tool for the family | Bilingual comparison, measured | Decided 2026-11-25 |
| Deadline | — | Hard: Thu 23:59 EAT, submit by 21:00 | Decided |
